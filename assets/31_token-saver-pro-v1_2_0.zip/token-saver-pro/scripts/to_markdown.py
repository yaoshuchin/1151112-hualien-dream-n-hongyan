#!/usr/bin/env python3
"""Local Markdown conversion with optional, manually installed MarkItDown.

Install in a Python 3.10+ virtual environment:
  python -m pip install "markitdown[docx,pptx,xlsx,xls,pdf]"
Images/audio may need additional dependencies or services; not guaranteed OCR.
"""
import argparse
from pathlib import Path
import sys
import zipfile

from common import collect_files, output_path, validate_output, write_text

SUPPORTED = {'.docx', '.pptx', '.xlsx', '.xls', '.csv', '.tsv', '.html', '.htm',
             '.epub', '.zip', '.jpg', '.jpeg', '.png', '.gif', '.bmp', '.mp3', '.wav', '.m4a'}


def convert_text(source, force_pdf=False):
    source = Path(source)
    if not source.is_file():
        raise FileNotFoundError('Input not found: ' + str(source))
    ext = source.suffix.lower()
    if ext == '.pdf' and not force_pdf:
        raise ValueError('PDF requires a separate PDF/OCR workflow or --force-pdf')
    if ext not in SUPPORTED and not (ext == '.pdf' and force_pdf):
        raise ValueError('Unsupported conversion format: ' + ext)
    office_members = {'.docx':'word/document.xml', '.pptx':'ppt/presentation.xml',
                      '.xlsx':'xl/workbook.xml'}
    if ext in office_members:
        try:
            with zipfile.ZipFile(source) as archive:
                if office_members[ext] not in archive.namelist():
                    raise ValueError('Missing Office document structure: ' + office_members[ext])
        except zipfile.BadZipFile as exc:
            raise ValueError('Invalid Office ZIP container: ' + str(source)) from exc
    try:
        from markitdown import MarkItDown
    except ImportError as exc:
        raise RuntimeError('MarkItDown is not installed. Use Python 3.10+ and manually run: '
                           'python -m pip install "markitdown[docx,pptx,xlsx,xls,pdf]"') from exc
    try:
        result = MarkItDown(enable_plugins=False).convert_local(str(source))
        text = getattr(result, 'text_content', None)
        if text is None:
            text = getattr(result, 'markdown', '')
        if not text or not text.strip():
            raise ValueError('Conversion returned empty content; no output written')
        return text
    except Exception as exc:
        raise RuntimeError('Conversion failed for {}: {}'.format(source, exc)) from exc


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input')
    parser.add_argument('-o', '--output', '--out', dest='output')
    parser.add_argument('--batch', action='store_true', help='input must be a directory')
    parser.add_argument('--recursive', action='store_true')
    parser.add_argument('--overwrite', action='store_true')
    parser.add_argument('--force-pdf', action='store_true')
    args = parser.parse_args()
    try:
        target = Path(args.input)
        if args.batch and not target.is_dir():
            raise ValueError('--batch requires a directory')
        sources = collect_files(target, args.recursive, args.output if target.is_dir() else None)
        plans, failures = [], 0
        seen = set()
        for source in sources:
            ext = source.suffix.lower()
            if target.is_dir() and ext not in SUPPORTED and ext != '.pdf':
                continue
            if ext == '.pdf' and not args.force_pdf:
                print('SKIP {}: use a separate PDF/OCR workflow or --force-pdf'.format(source))
                failures += 1
                continue
            destination = output_path(source, target, args.output, '.md')
            validate_output(destination, sources, args.overwrite)
            key = str(destination.resolve()).casefold()
            if key in seen:
                raise ValueError('Multiple sources would share output: ' + str(destination))
            seen.add(key)
            plans.append((source, destination))
        done = 0
        for source, destination in plans:
            try:
                text = convert_text(source, args.force_pdf)
                write_text(destination, text, sources, args.overwrite)
                done += 1
                print('OK {} -> {}'.format(source, destination))
            except (OSError, ValueError, RuntimeError) as exc:
                failures += 1
                print('FAIL {}: {}'.format(source, exc), file=sys.stderr)
        return 1 if failures or not done else 0
    except (OSError, ValueError) as exc:
        print('ERROR: ' + str(exc), file=sys.stderr)
        return 1


if __name__ == '__main__':
    sys.exit(main())
