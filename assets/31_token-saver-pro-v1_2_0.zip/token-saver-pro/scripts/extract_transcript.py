#!/usr/bin/env python3
"""Normalize JSONL conversations into a traceable digest (stdlib only).

Conversation text is unlimited by default; tool bodies use a visible head/tail
excerpt. This is deterministic extraction, not a semantic summary or an archive.
"""
import argparse
from collections import Counter
from datetime import datetime
import hashlib
import json
from pathlib import Path
import sys

from common import collect_files, nonnegative, validate_output, write_text


def as_text(value):
    if value is None:
        return ''
    if isinstance(value, str):
        return value
    return json.dumps(value, ensure_ascii=False, sort_keys=True)


def text_blocks(value):
    if isinstance(value, str):
        return value
    if isinstance(value, list):
        return '\n'.join(as_text(b.get('text', '')) if isinstance(b, dict)
                         and b.get('type') in ('text', 'input_text', 'output_text')
                         else '[attachment] ' + as_text(attachment(b)) for b in value)
    return as_text(value)


def attachment(value):
    """Keep references and MIME information without copying inline binary bodies."""
    if isinstance(value, str) and value.startswith('data:'):
        return value.split(',', 1)[0] + ',[inline binary omitted: {} chars]'.format(len(value))
    if isinstance(value, list):
        return [attachment(v) for v in value]
    if isinstance(value, dict):
        return {k: ('[inline binary omitted: {} chars]'.format(len(as_text(v)))
                    if k == 'data' and (value.get('type') == 'base64'
                                        or value.get('encoding') == 'base64')
                    else attachment(v)) for k, v in value.items()}
    return value


def entry(kind, body, **metadata):
    if kind.startswith('tool_') and isinstance(body, (dict, list)):
        body = attachment(body)
    return dict(kind=kind, body=as_text(body), **metadata)


def message_entries(message):
    role = message.get('role') or message.get('type')
    role = {'model':'assistant', 'human':'user'}.get(role, role)
    if role not in ('user', 'assistant', 'tool', 'function'):
        return []
    content = message.get('content', message.get('parts', ''))
    if role in ('tool', 'function'):
        return [entry('tool_result', content,
                      id=message.get('tool_call_id'), name=message.get('name'))]
    entries = []
    if isinstance(content, str) and content.strip():
        entries.append(entry(role, content, phase=message.get('phase'),
                             channel=message.get('channel')))
    elif isinstance(content, list):
        for block in content:
            if not isinstance(block, dict):
                entries.append(entry(role, '[non-text content] ' + as_text(block)))
                continue
            kind = block.get('type')
            if kind in ('text', 'input_text', 'output_text') or 'text' in block:
                if not block.get('thought') and block.get('text'):
                    entries.append(entry(role, block['text'], phase=message.get('phase'),
                                         channel=message.get('channel')))
            elif kind == 'tool_use':
                entries.append(entry('tool_call', block.get('input', {}),
                                     id=block.get('id'), name=block.get('name')))
            elif kind == 'tool_result':
                body = text_blocks(block.get('content', ''))
                if not body:
                    body = as_text(block.get('content', ''))
                entries.append(entry('tool_result', body, id=block.get('tool_use_id'),
                                     error=block.get('is_error')))
            elif 'functionCall' in block:
                call = block['functionCall']
                entries.append(entry('tool_call', call.get('args', {}),
                                     name=call.get('name'), id=call.get('id')))
            elif 'functionResponse' in block:
                result = block['functionResponse']
                entries.append(entry('tool_result', result.get('response', {}),
                                     name=result.get('name'), id=result.get('id')))
            elif kind not in ('thinking', 'redacted_thinking'):
                entries.append(entry(role, '[attachment/unknown block] ' + as_text(attachment(block))))
    for call in message.get('tool_calls', []) or []:
        function = call.get('function', {})
        entries.append(entry('tool_call', function.get('arguments', ''),
                             id=call.get('id'), name=function.get('name')))
    call = message.get('function_call')
    if isinstance(call, dict):
        entries.append(entry('tool_call', call.get('arguments', ''), name=call.get('name')))
    return entries


def normalize(obj):
    """Return records and a wrapper tag, preserving source order and tool IDs."""
    kind = obj.get('type')
    if kind == 'response_item':
        payload = obj.get('payload')
        if not isinstance(payload, dict):
            return [], 'unknown'
        subtype = payload.get('type')
        if subtype == 'message':
            return message_entries(payload), 'response'
        if subtype in ('function_call', 'custom_tool_call'):
            return [entry('tool_call', payload.get('arguments', payload.get('input', '')),
                          id=payload.get('call_id'), name=payload.get('name'))], 'response'
        if subtype in ('function_call_output', 'custom_tool_call_output'):
            return [entry('tool_result', payload.get('output', ''),
                          id=payload.get('call_id'))], 'response'
        if subtype in ('web_search_call', 'local_shell_call'):
            return [entry('tool_call', payload, id=payload.get('call_id', payload.get('id')),
                          name=subtype)], 'response'
        return [], 'metadata' if subtype == 'reasoning' else 'unknown'
    if kind == 'event_msg':
        payload = obj.get('payload')
        if not isinstance(payload, dict):
            return [], 'unknown'
        subtype = payload.get('type')
        if subtype in ('user_message', 'agent_message'):
            role = 'user' if subtype == 'user_message' else 'assistant'
            return [entry(role, payload.get('message', ''),
                          phase=payload.get('phase'))], 'event'
        if subtype in ('task_complete', 'turn_complete'):
            status = {k:v for k,v in payload.items() if k != 'last_agent_message'}
            records = [entry('status', status, name=subtype)]
            if payload.get('last_agent_message'):
                records.append(entry('assistant', payload['last_agent_message']))
            return records, 'complete'
        if subtype in ('token_count', 'agent_reasoning', 'agent_reasoning_raw_content',
                       'agent_reasoning_section_break', 'context_compacted'):
            return [], 'metadata'
        if subtype in ('exec_command_begin', 'mcp_tool_call_begin', 'patch_apply_begin'):
            return [entry('tool_call', payload, name=subtype,
                          id=payload.get('call_id'))], 'event'
        if subtype in ('exec_command_end', 'mcp_tool_call_end', 'patch_apply_end'):
            return [entry('tool_result', payload, name=subtype,
                          id=payload.get('call_id'))], 'event'
        return [entry('status', payload, name=subtype)], 'event'
    if kind == 'compacted' and isinstance(obj.get('payload'), dict):
        payload = obj['payload']
        if payload.get('message'):
            return [entry('compaction_summary', payload['message'])], 'message'
        return [], 'unknown'
    if isinstance(obj.get('message'), dict):
        message = dict(obj['message'])
        if not message.get('role') and kind in ('user', 'assistant'):
            message['role'] = kind
        return message_entries(message), 'message'
    if isinstance(obj.get('contents'), list):
        records = []
        for message in obj['contents']:
            if isinstance(message, dict):
                records.extend(message_entries(message))
        return records, 'message'
    if obj.get('role') or kind in ('user', 'assistant'):
        return message_entries(obj), 'message'
    if kind in ('session_meta', 'turn_context', 'system', 'progress', 'summary'):
        return [], 'metadata'
    return [], 'unknown'


def scan(path, diagnose=True):
    """Stream input; retain source line numbers, even for malformed records."""
    with Path(path).open('r', encoding='utf-8-sig', errors='strict') as stream:
        turn_id = None
        for number, line in enumerate(stream, 1):
            if not line.strip():
                continue
            try:
                obj = json.loads(line)
                if not isinstance(obj, dict):
                    raise ValueError('JSON record must be an object')
                payload = obj.get('payload')
                payload = payload if isinstance(payload, dict) else {}
                explicit_turn = obj.get('turn_id') or payload.get('turn_id')
                if explicit_turn:
                    turn_id = explicit_turn
                records, tag = normalize(obj)
                for record in records:
                    record.update(line=number, timestamp=obj.get('timestamp', obj.get('time')),
                                  turn_id=turn_id)
                yield records, tag, number
            except (ValueError, TypeError, AttributeError) as exc:
                if diagnose:
                    print('WARNING {} line={}: {}'.format(path, number, exc), file=sys.stderr)
                yield [], 'invalid', number


def excerpt(text, limit):
    if not limit or len(text) <= limit:
        return text
    head = (limit + 1) // 2
    tail = limit // 2
    return (text[:head] + '\n[TRUNCATED: {} chars omitted; inspect source line]\n'.format(
            len(text) - limit) + (text[-tail:] if tail else ''))


def signature(record):
    return record['kind'], hashlib.sha256(record['body'].encode('utf-8')).digest()


def same_mirror(first, second):
    """Only collapse a nearby counterpart with corroborating turn/time metadata."""
    if abs(first['line'] - second['line']) > 8:
        return False
    if first.get('turn_id') and second.get('turn_id'):
        return first['turn_id'] == second['turn_id']
    if first.get('timestamp') and second.get('timestamp'):
        try:
            a = datetime.fromisoformat(first['timestamp'].replace('Z', '+00:00'))
            b = datetime.fromisoformat(second['timestamp'].replace('Z', '+00:00'))
            return abs((a-b).total_seconds()) <= 1
        except (ValueError, TypeError, AttributeError):
            pass
    return False


def consume_mirror(pool, record):
    candidates = pool.get(signature(record), [])
    for index, candidate in enumerate(candidates):
        if same_mirror(candidate, record):
            candidates.pop(index)
            return True
    return False


def extract_file(path, max_chars=0, tool_max_chars=2000, users_only=False):
    """Two streaming passes suppress mirrored Codex event records by occurrence.

    Never globally de-duplicate messages: repeated approvals/questions are real turns.
    """
    canonical = {}
    completion = {}
    for records, tag, _ in scan(path, diagnose=False):
        for rec in records:
            if tag == 'response' and rec['kind'] in ('user', 'assistant'):
                canonical.setdefault(signature(rec), []).append(
                    {k:v for k,v in rec.items() if k != 'body'})
            if tag in ('event', 'response') and rec['kind'] == 'assistant':
                completion.setdefault(signature(rec), []).append(
                    {k:v for k,v in rec.items() if k != 'body'})
    lines = ['\n# Source: ' + str(path),
             '# Conversation limit={} / tool limit={} chars (0=unlimited)'.format(
                 max_chars, tool_max_chars)]
    stats = Counter()
    for records, tag, number in scan(path):
        stats[tag] += 1
        if tag == 'unknown':
            print('WARNING {} line={}: unsupported record schema'.format(path, number),
                  file=sys.stderr)
        for rec in records:
            if tag == 'event' and consume_mirror(canonical, rec):
                stats['mirrors_skipped'] += 1
                continue
            if tag == 'complete' and rec['kind'] == 'assistant' and consume_mirror(completion, rec):
                stats['mirrors_skipped'] += 1
                continue
            if users_only and rec['kind'] != 'user':
                continue
            tool = rec['kind'].startswith('tool_')
            if not rec['body'].strip():
                if tool:
                    rec['body'] = '[empty tool body]'
                else:
                    continue
            body = excerpt(rec['body'], tool_max_chars if tool else max_chars)
            stats['truncated'] += int(body != rec['body'])
            metadata = ' '.join('{}={}'.format(k, as_text(v).replace('\n', '\\n'))
                                for k, v in rec.items()
                                if k not in ('body', 'kind') and v is not None)
            lines.extend(['\n## {} {}'.format(rec['kind'], metadata), body])
            stats['records'] += 1
    lines.append('\n# Stats: ' + json.dumps(dict(stats), sort_keys=True))
    return '\n'.join(lines) + '\n', stats


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('target', help='JSONL file or directory')
    parser.add_argument('-o', '--out', help='combined digest file; default stdout')
    parser.add_argument('--max-chars', type=nonnegative, default=0,
                        help='conversation chars per text block; 0=unlimited (default)')
    parser.add_argument('--tool-max-chars', type=nonnegative, default=2000,
                        help='tool chars per record; 0=unlimited (default 2000)')
    parser.add_argument('--users-only', action='store_true', help='explicit lossy user-only view')
    parser.add_argument('--recursive', action='store_true')
    parser.add_argument('--overwrite', action='store_true')
    args = parser.parse_args()
    try:
        all_sources = collect_files(args.target, args.recursive)
        files = [p for p in all_sources if p.suffix.lower() == '.jsonl']
        if not files:
            raise ValueError('No JSONL inputs found')
        if args.out:
            validate_output(args.out, all_sources, args.overwrite)
        pieces, total = [], Counter()
        for path in files:
            text, stats = extract_file(path, args.max_chars, args.tool_max_chars, args.users_only)
            pieces.append(text)
            total.update(stats)
        if not total['records']:
            raise ValueError('No supported conversation/tool records; no digest written')
        text = ''.join(pieces)
        if args.out:
            write_text(args.out, text, all_sources, args.overwrite)
            print('Written {} ({} records, {} truncated)'.format(
                args.out, total['records'], total['truncated']))
        else:
            print(text, end='')
        return 2 if total['invalid'] or total['unknown'] else 0
    except (OSError, ValueError, UnicodeError) as exc:
        print('ERROR: ' + str(exc), file=sys.stderr)
        return 1


if __name__ == '__main__':
    sys.exit(main())
