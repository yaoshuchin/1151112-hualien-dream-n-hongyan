#!/usr/bin/env python3
"""Route local files to transcript extraction or Markdown conversion.

Output names preserve the source extension; overwrite is always opt-in.
No dependency is installed automatically. Reports measure bytes, not tokens.
"""
import argparse
from pathlib import Path
import sys

from common import collect_files, nonnegative, output_path, validate_output, write_text
from extract_transcript import extract_file
from to_markdown import SUPPORTED, convert_text


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('target')
    parser.add_argument('-o', '--out')
    parser.add_argument('--force-pdf', action='store_true')
    parser.add_argument('--recursive', action='store_true')
    parser.add_argument('--overwrite', action='store_true')
    parser.add_argument('--max-chars', type=nonnegative, default=0)
    parser.add_argument('--tool-max-chars', type=nonnegative, default=2000)
    parser.add_argument('--users-only', action='store_true')
    args = parser.parse_args()
    try:
        target = Path(args.target)
        sources = collect_files(target, args.recursive, args.out if target.is_dir() else None)
        failures, done, raw_total, new_total = 0, 0, 0, 0
        plans = []
        destinations = set()
        for source in sources:
            ext = source.suffix.lower()
            if ext == '.pdf' and not args.force_pdf:
                print('SKIP {}: PDF requires a separate PDF/OCR workflow or --force-pdf'.format(source))
                failures += 1
                continue
            if ext != '.jsonl' and ext not in SUPPORTED and not (ext == '.pdf' and args.force_pdf):
                print('SKIP {}: unsupported/plain-text input'.format(source))
                continue
            suffix = '.digest.txt' if ext == '.jsonl' else '.md'
            destination = output_path(source, target, args.out, suffix)
            validate_output(destination, sources, args.overwrite)
            key = str(destination.resolve()).casefold()
            if key in destinations:
                raise ValueError('Multiple sources would share output: ' + str(destination))
            destinations.add(key)
            plans.append((source, destination, ext))
        for source, destination, ext in plans:
            try:
                if ext == '.jsonl':
                    text, stats = extract_file(source, args.max_chars, args.tool_max_chars, args.users_only)
                    if not stats['records']:
                        raise ValueError('No supported conversation/tool records')
                    partial = stats['invalid'] or stats['unknown']
                else:
                    text = convert_text(source, args.force_pdf)
                    partial = False
                write_text(destination, text, sources, args.overwrite)
                raw, new = source.stat().st_size, destination.stat().st_size
                raw_total += raw
                new_total += new
                done += 1
                failures += int(bool(partial))
                print('{} {} -> {} ({} -> {} bytes)'.format(
                    'PARTIAL' if partial else 'OK', source, destination, raw, new))
            except (OSError, ValueError, RuntimeError, UnicodeError) as exc:
                failures += 1
                print('FAIL {}: {}'.format(source, exc), file=sys.stderr)
        print('Processed {} file(s); {} failure/partial/blocked item(s).'.format(done, failures))
        if raw_total:
            print('Byte reduction: {:.1f}% (NOT a token count).'.format(
                (1 - new_total / raw_total) * 100))
        return 1 if failures or not done else 0
    except (OSError, ValueError) as exc:
        print('ERROR: ' + str(exc), file=sys.stderr)
        return 1


if __name__ == '__main__':
    sys.exit(main())
