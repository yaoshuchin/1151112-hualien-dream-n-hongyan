"""Shared local-file policies. No network access or dependency installation."""
import argparse
import os
from pathlib import Path
import tempfile


def nonnegative(value):
    number = int(value)
    if number < 0:
        raise argparse.ArgumentTypeError('limit must be >= 0 (0 means unlimited)')
    return number


def validate_output(destination, sources, overwrite=False):
    dst = Path(destination)
    resolved = dst.resolve()
    for source in sources:
        src = Path(source)
        if resolved == src.resolve() or (dst.exists() and src.exists()
                                        and os.path.samefile(dst, src)):
            raise ValueError('Output must not replace a source file: ' + str(dst))
    if dst.exists() and not overwrite:
        raise FileExistsError('Output exists; choose another path or use --overwrite: ' + str(dst))
    if dst.is_dir():
        raise IsADirectoryError(str(dst))


def write_text(destination, text, sources=(), overwrite=False):
    """Stage UTF-8 then atomically publish without replacing an existing output."""
    dst = Path(destination)
    validate_output(dst, sources, overwrite)
    dst.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix='.token-saver-', dir=str(dst.parent))
    try:
        with os.fdopen(fd, 'w', encoding='utf-8', newline='\n') as stream:
            stream.write(text)
        validate_output(dst, sources, overwrite)
        if overwrite:
            os.replace(temporary, dst)
        elif os.name == 'nt':
            # Windows rename fails if the destination exists, including races.
            # Unlike hardlinks, it also works in restricted Windows sandboxes.
            os.rename(temporary, dst)
        else:
            os.link(temporary, dst)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def generated(path):
    name = path.name.lower()
    return name.endswith(('.md', '.digest.txt')) or name.startswith('.token-saver-')


def collect_files(target, recursive=False, exclude=None):
    target = Path(target)
    if not target.exists():
        raise FileNotFoundError('Input not found: ' + str(target))
    if target.is_file():
        return [target]
    excluded = Path(exclude).resolve() if exclude else None
    if excluded == target.resolve():
        excluded = None
    files = []
    for current, dirs, names in os.walk(target, followlinks=False):
        dirs[:] = sorted(d for d in dirs if not (Path(current) / d).is_symlink()
                         and (excluded is None or (Path(current) / d).resolve() != excluded))
        for name in sorted(names):
            path = Path(current) / name
            if path.is_file() and not path.is_symlink() and not generated(path):
                files.append(path)
        if not recursive:
            break
    return files


def output_path(source, target, output, suffix):
    source, target = Path(source), Path(target)
    if target.is_dir():
        relative = source.relative_to(target)
        return (Path(output) if output else target) / relative.parent / (source.name + suffix)
    if output:
        result = Path(output)
        if result.is_dir() or str(output).endswith(('/', '\\')):
            return result / (source.name + suffix)
        return result
    return source.with_name(source.name + suffix)
