# 逐字稿格式與已知限制

所有輸入均為 UTF-8 JSONL（可有 BOM），每行一個 JSON object。
不把一般 `.log` 當 JSONL，不自動把 Big5 亂碼改成空白。

| 格式 | 已實作辨識 |
|---|---|
| Codex rollout | `response_item.payload` 的 `message`、`function_call`／`function_call_output`、`custom_tool_call`／`custom_tool_call_output`、`web_search_call`、`local_shell_call` |
| Codex events | `user_message`、`agent_message`；新 `turn_complete`／舊 `task_complete` 的最後答覆及狀態；中止、錯誤、其他狀態事件 |
| Codex legacy tools | `exec_command_begin/end`、`mcp_tool_call_begin/end`、`patch_apply_begin/end` |
| Codex compaction | `compacted.payload.message` 以 `compaction_summary` 保留；不重新展開 replacement_history，以免把歷史重覆灌入 |
| Claude | `type=user/assistant` + `message.content`，文字、`tool_use`、`tool_result`、`is_error` |
| role-based | 頂層或 `message` 內的 `role=user/assistant/tool/function`；`tool_calls`、舊 `function_call` |
| Gemini-style | `role=user/model` + `parts`；`functionCall`、`functionResponse`；可包在 `contents` 陣列內 |

保留來源路徑、原始行號、timestamp/time、回合 ID（有提供或由 turn_context 等延續）、phase/channel、工具 ID／名稱（來源有提供時）。
未知頂層／response 結構會警告，部分結果回非零；可用新的合成 fixture 擴充格式後再處理。
`session_meta`、`turn_context`、token 計數、reasoning／thinking 等背景或思考內容不匯出。
圖片／檔案附件只保留參照資訊與省略標記，沒有影像分析或附件內容下載。

鏡像去重以相同角色、完全相同文字和鄰近來源行為前提；不同回合 ID 永不合併。
雙方都有回合 ID 時使用 ID 核對；否則需要可解析、相差不超過一秒的時間戳。
每次配對消耗一筆對應紀錄；正常重複問句與短回覆不做全域去重。
時間／回合資訊不足或相隔過遠時保留重複；這是保守行為，不能承諾消除所有鏡像。

輸出是有選擇的文字檢視，不是日誌備份、對話狀態的完整重建，也不是語意重要性分類器。
若要確認過去做了什麼，須同時看 assistant、tool_result、status；若要確認現在是否完成，須驗實際成果。

格式查核參考（仍以實際輸入及測試 fixture 為準）：
- [OpenAI Codex rollout reconstruction](https://github.com/openai/codex/blob/main/codex-rs/core/src/session/rollout_reconstruction.rs)
- [OpenAI Codex rollout migration fixtures](https://github.com/openai/codex/blob/main/codex-rs/thread-store/src/local/rollout_migration_tests.rs)
