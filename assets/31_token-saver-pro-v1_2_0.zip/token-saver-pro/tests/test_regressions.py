"""Black-box regressions. All inputs are synthetic; no personal logs are read."""
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

try:
    from markitdown import MarkItDown
    HAS_MARKITDOWN = True
except ImportError:
    HAS_MARKITDOWN = False

ROOT = Path(__file__).resolve().parents[1]


class CLITests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.base = Path(self.temp.name)

    def run_script(self, script, *args):
        env = dict(os.environ, PYTHONIOENCODING="utf-8", PYTHONUTF8="1")
        return subprocess.run([sys.executable, str(ROOT / 'scripts' / script),
                               *map(str, args)], capture_output=True,
                              encoding='utf-8', env=env)

    def log(self, rows, name='sample.jsonl'):
        p = self.base / name
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text('\n'.join(json.dumps(r, ensure_ascii=False) for r in rows),
                     encoding='utf-8')
        return p

    def extract(self, rows, *args):
        src = self.log(rows)
        dst = self.base / 'digest.txt'
        result = self.run_script('extract_transcript.py', src, '--out', dst, *args)
        self.assertEqual(result.returncode, 0, result.stderr + result.stdout)
        return dst.read_text(encoding='utf-8')

    def test_codex_response_messages(self):
        text = self.extract([
            {'type':'response_item','timestamp':'2026-10-29T01:00:00Z','payload':
             {'type':'message','role':'user','content':[{'type':'input_text','text':'fix this'}]}},
            {'type':'response_item','payload':{'type':'message','role':'assistant',
              'phase':'final_answer','content':[{'type':'output_text','text':'fixed and tested'}]}}])
        for value in ('fix this', 'fixed and tested', '2026-10-29', 'line=1', 'assistant'):
            self.assertIn(value, text)

    def test_codex_function_call_and_result(self):
        text = self.extract([
            {'type':'response_item','payload':{'type':'function_call','name':'exec_command',
             'call_id':'call_42','arguments':'{"cmd":"pytest"}'}},
            {'type':'response_item','payload':{'type':'function_call_output',
             'call_id':'call_42','output':'Exit code: 1\nFAILED regression'}}])
        for value in ('call_42', 'exec_command', 'pytest', 'FAILED regression', 'tool_result'):
            self.assertIn(value, text)

    def test_codex_custom_tool(self):
        text = self.extract([
            {'type':'response_item','payload':{'type':'custom_tool_call','name':'apply_patch',
             'call_id':'patch_1','input':'*** Begin Patch'}},
            {'type':'response_item','payload':{'type':'custom_tool_call_output',
             'call_id':'patch_1','output':'Success'}}])
        for value in ('apply_patch', 'patch_1', '*** Begin Patch', 'Success'):
            self.assertIn(value, text)

    def test_event_only_codex(self):
        text = self.extract([
            {'type':'event_msg','payload':{'type':'user_message','message':'please check'}},
            {'type':'event_msg','payload':{'type':'agent_message','message':'verified'}}])
        self.assertIn('please check', text)
        self.assertIn('verified', text)

    def test_mirrored_events_dedup_without_dropping_repeated_turns(self):
        rows = []
        for _ in range(2):
            rows += [
                {'type':'event_msg','turn_id':str(_),'payload':{'type':'user_message','message':'same request'}},
                {'type':'response_item','turn_id':str(_),'payload':{'type':'message','role':'user',
                 'content':[{'type':'input_text','text':'same request'}]}}]
        self.assertEqual(self.extract(rows).count('same request'), 2)

    def test_identical_text_in_different_turns_not_deduplicated(self):
        text=self.extract([
            {'type':'event_msg','turn_id':'one','payload':{'type':'user_message','message':'OK'}},
            {'type':'response_item','turn_id':'two','payload':{'type':'message','role':'user',
             'content':[{'type':'input_text','text':'OK'}]}}])
        self.assertEqual(text.count('\nOK\n'),2)

    def test_event_errors_and_interrupts_preserved(self):
        text=self.extract([
            {'type':'event_msg','payload':{'type':'turn_aborted','reason':'user_interrupt'}},
            {'type':'event_msg','payload':{'type':'error','message':'permission denied'}}])
        for value in ('turn_aborted','user_interrupt','permission denied'):
            self.assertIn(value,text)

    def test_compaction_summary_preserved(self):
        text=self.extract([{'type':'compacted','payload':{'message':'Keep the agreed deadline'}}])
        self.assertIn('compaction_summary',text)
        self.assertIn('Keep the agreed deadline',text)

    def test_empty_tool_result_preserved(self):
        text=self.extract([{'type':'response_item','payload':{
            'type':'function_call_output','call_id':'empty_call','output':''}}])
        self.assertIn('empty_call',text)
        self.assertIn('empty',text.lower())

    def test_tool_result_attachment_preserved_without_binary(self):
        text=self.extract([{'type':'user','message':{'content':[
            {'type':'tool_result','tool_use_id':'image_call','content':[
             {'type':'text','text':'screenshot'},
             {'type':'image','source':{'type':'url','url':'https://example.invalid/a.png'}}]}]}}])
        self.assertIn('screenshot',text)
        self.assertIn('https://example.invalid/a.png',text)

    def test_inline_image_binary_excluded(self):
        text=self.extract([{'role':'user','content':[
            {'type':'input_image','image_url':'data:image/png;base64,UNIQUE_BINARY_PAYLOAD'},
            {'type':'image','source':{'type':'base64','media_type':'image/png',
                                      'data':'SECOND_BINARY_PAYLOAD'}}]}])
        self.assertNotIn('UNIQUE_BINARY_PAYLOAD',text)
        self.assertNotIn('SECOND_BINARY_PAYLOAD',text)
        self.assertIn('image/png',text)

    def test_structured_tool_binary_excluded_even_without_limit(self):
        text=self.extract([
            {'role':'tool','tool_call_id':'image1','content':[
             {'type':'image_url','image_url':{'url':'data:image/png;base64,TOOL_BINARY'}}]},
            {'type':'response_item','payload':{'type':'function_call_output','call_id':'image2',
             'output':{'type':'image','source':{'type':'base64','media_type':'image/png',
                                             'data':'CODEX_BINARY'}}}}],
            '--tool-max-chars','0')
        self.assertNotIn('TOOL_BINARY',text)
        self.assertNotIn('CODEX_BINARY',text)
        self.assertIn('image1',text)
        self.assertIn('image2',text)

    def test_top_level_roles_and_short_chinese(self):
        text = self.extract([{'role':'user','content':'好'},
                             {'role':'assistant','content':'收到'}])
        self.assertIn('好', text)
        self.assertIn('收到', text)

    def test_claude_tools_mixed_with_user_text(self):
        text = self.extract([
            {'type':'assistant','message':{'role':'assistant','content':[
                {'type':'text','text':'checking now'},
                {'type':'tool_use','id':'toolu_1','name':'Read','input':{'file_path':'x.py'}}]}},
            {'type':'user','message':{'role':'user','content':[
                {'type':'tool_result','tool_use_id':'toolu_1','is_error':True,
                 'content':[{'type':'text','text':'file missing'}]},
                {'type':'text','text':'try another file'}]}}])
        for value in ('checking now','toolu_1','Read','x.py','file missing','try another file','error'):
            self.assertIn(value, text)

    def test_openai_tool_calls(self):
        text = self.extract([
            {'role':'assistant','content':None,'tool_calls':[{'id':'c1','type':'function',
             'function':{'name':'lookup','arguments':'{"q":"lesson"}'}}]},
            {'role':'tool','tool_call_id':'c1','content':'found lesson'}])
        for value in ('c1','lookup','found lesson'):
            self.assertIn(value, text)

    def test_gemini_parts(self):
        text = self.extract([
            {'role':'user','parts':[{'text':'find material'}]},
            {'role':'model','parts':[{'text':'done'},
             {'functionCall':{'name':'search','args':{'q':'material'}}}]},
            {'role':'user','parts':[{'functionResponse':{'name':'search',
              'response':{'result':'found'}}}]}])
        for value in ('find material','done','search','found'):
            self.assertIn(value, text)

    def test_html_and_full_conversation_preserved(self):
        body = '<button>送出</button>\n' + 'A' * 1500 + 'final requirement'
        text = self.extract([{'type':'user','message':{'content':body}}])
        self.assertIn(body, text)

    def test_explicit_truncation_retains_tail(self):
        text = self.extract([{'role':'user','content':'HEAD'+'x'*100+'IMPORTANT_TAIL'}],
                            '--max-chars', '40')
        self.assertIn('HEAD', text)
        self.assertIn('IMPORTANT_TAIL', text)
        self.assertIn('TRUNCATED', text)

    def test_tool_truncation_retains_exit_status(self):
        text = self.extract([{'role':'tool','tool_call_id':'c2',
                             'content':'START'+'x'*5000+'Exit code: 1'}],
                            '--tool-max-chars','100')
        for value in ('START', 'Exit code: 1', 'TRUNCATED', 'c2'):
            self.assertIn(value, text)

    def test_users_only_is_explicit(self):
        text = self.extract([{'role':'user','content':'question'},
                             {'role':'assistant','content':'answer'}], '--users-only')
        self.assertIn('question', text)
        self.assertNotIn('answer', text)

    def test_invalid_json_diagnosed_partial_is_nonzero(self):
        src = self.base / 'broken.jsonl'
        src.write_text('{oops}\n'+json.dumps({'role':'user','content':'keep valid'}),encoding='utf-8')
        dst = self.base / 'result.txt'
        result = self.run_script('extract_transcript.py',src,'--out',dst)
        self.assertNotEqual(result.returncode,0)
        self.assertIn('line=1',result.stderr)
        self.assertIn('keep valid',dst.read_text(encoding='utf-8'))

    def test_unknown_schema_is_not_successful_empty_digest(self):
        src = self.log([{'unrecognized':'record'}])
        dst = self.base / 'out.txt'
        result = self.run_script('extract_transcript.py',src,'--out',dst)
        self.assertNotEqual(result.returncode,0)
        self.assertFalse(dst.exists())

    def test_existing_output_not_overwritten(self):
        src = self.log([{'type':'user','message':{'content':'new message'}}])
        dst = self.base / 'digest.txt'
        dst.write_text('KEEP ME',encoding='utf-8')
        result = self.run_script('extract_transcript.py',src,'--out',dst)
        self.assertNotEqual(result.returncode,0)
        self.assertEqual(dst.read_text(encoding='utf-8'),'KEEP ME')

    def test_explicit_overwrite(self):
        src = self.log([{'role':'user','content':'new message'}])
        dst = self.base / 'digest.txt'
        dst.write_text('old',encoding='utf-8')
        result = self.run_script('extract_transcript.py',src,'--out',dst,'--overwrite')
        self.assertEqual(result.returncode,0,result.stderr)
        self.assertIn('new message',dst.read_text(encoding='utf-8'))

    def test_source_cannot_be_output_even_with_overwrite(self):
        src = self.log([{'type':'user','message':{'content':'keep source'}}])
        original = src.read_bytes()
        result = self.run_script('extract_transcript.py',src,'--out',src,'--overwrite')
        self.assertNotEqual(result.returncode,0)
        self.assertEqual(src.read_bytes(),original)

    @unittest.skipUnless(HAS_MARKITDOWN, 'optional MarkItDown integration unavailable')
    def test_slim_same_stem_keeps_both_extensions(self):
        src_dir = self.base / 'inputs'
        src_dir.mkdir()
        for name, content in [('lesson.html','<h1>HTML lesson</h1>'),
                              ('lesson.csv','topic,value\nCSV lesson,2')]:
            (src_dir/name).write_text(content,encoding='utf-8')
        out = self.base / 'out'
        result = self.run_script('slim.py',src_dir,'--out',out)
        self.assertEqual(result.returncode,0,result.stderr+result.stdout)
        self.assertIn('HTML lesson',(out/'lesson.html.md').read_text(encoding='utf-8'))
        self.assertIn('CSV lesson',(out/'lesson.csv.md').read_text(encoding='utf-8'))

    def test_slim_recursive_keeps_tree_and_skips_outputs(self):
        source = self.base / 'inputs'
        self.log([{'role':'user','content':'first branch'}],'inputs/a/same.jsonl')
        self.log([{'role':'user','content':'second branch'}],'inputs/b/same.jsonl')
        out = source / 'converted'
        result = self.run_script('slim.py',source,'--out',out,'--recursive')
        self.assertEqual(result.returncode,0,result.stderr+result.stdout)
        for branch,value in [('a','first branch'),('b','second branch')]:
            self.assertIn(value,(out/branch/'same.jsonl.digest.txt').read_text(encoding='utf-8'))
        again = self.run_script('slim.py',source,'--out',out,'--recursive','--overwrite')
        self.assertEqual(again.returncode,0,again.stderr+again.stdout)
        self.assertEqual(len(list(out.rglob('*.digest.txt'))),2)

    def test_slim_forwards_limits(self):
        src = self.log([{'role':'assistant','content':'HEAD'+'x'*500+'TAIL'}])
        dst = self.base/'out.txt'
        result = self.run_script('slim.py',src,'--out',dst,'--max-chars','60')
        self.assertEqual(result.returncode,0,result.stderr+result.stdout)
        text = dst.read_text(encoding='utf-8')
        self.assertIn('TRUNCATED',text)
        self.assertIn('TAIL',text)

    def test_slim_failures_have_nonzero_status(self):
        src = self.log([{'unexpected':'schema'}])
        result = self.run_script('slim.py',src)
        self.assertNotEqual(result.returncode,0)

    def test_missing_input_does_not_install_packages(self):
        result = self.run_script('to_markdown.py',self.base/'missing.docx')
        self.assertNotEqual(result.returncode,0)
        self.assertNotIn('pip install -q',result.stdout+result.stderr)

    def test_pdf_default_explicitly_skipped(self):
        src=self.base/'x.pdf'
        src.write_bytes(b'%PDF-1.4')
        result=self.run_script('slim.py',src)
        self.assertNotEqual(result.returncode,0)
        self.assertFalse((self.base/'x.pdf.md').exists())

    def test_negative_limit_rejected(self):
        src=self.log([{'role':'user','content':'retain me'}])
        result=self.run_script('extract_transcript.py',src,'--max-chars','-1')
        self.assertNotEqual(result.returncode,0)

    def test_time_separated_messages_not_deduplicated(self):
        text=self.extract([
            {'type':'event_msg','timestamp':'2026-10-29T00:00:00Z',
             'payload':{'type':'user_message','message':'OK'}},
            {'type':'response_item','timestamp':'2026-10-29T01:00:00Z',
             'payload':{'type':'message','role':'user','content':'OK'}}])
        self.assertEqual(text.count('\nOK\n'),2)

    def test_timestamp_mirrors_deduplicated(self):
        text=self.extract([
            {'type':'event_msg','timestamp':'2026-10-29T00:00:00.100Z',
             'payload':{'type':'agent_message','message':'done'}},
            {'type':'response_item','timestamp':'2026-10-29T00:00:00.200Z',
             'payload':{'type':'message','role':'assistant','content':'done'}},
            {'type':'event_msg','timestamp':'2026-10-29T00:00:00.300Z',
             'payload':{'type':'turn_complete','last_agent_message':'done','error':None}}])
        self.assertEqual(text.count('\ndone\n'),1)
        self.assertIn('turn_complete',text)

    def test_uncertain_mirrors_kept(self):
        text=self.extract([
            {'type':'event_msg','payload':{'type':'user_message','message':'OK'}},
            {'type':'response_item','payload':{'type':'message','role':'user','content':'OK'}}])
        self.assertEqual(text.count('\nOK\n'),2)

    def test_turn_context_applies_to_mirrors(self):
        text=self.extract([
            {'type':'turn_context','payload':{'turn_id':'t1'}},
            {'type':'event_msg','payload':{'type':'user_message','message':'confirm'}},
            {'type':'response_item','payload':{'type':'message','role':'user','content':'confirm'}}])
        self.assertEqual(text.count('\nconfirm\n'),1)

    def test_completion_error_kept_even_when_text_mirrored(self):
        text=self.extract([
            {'type':'response_item','turn_id':'t1','payload':{
                'type':'message','role':'assistant','content':'stopped'}},
            {'type':'event_msg','turn_id':'t1','payload':{
                'type':'turn_complete','last_agent_message':'stopped','error':'network lost'}}])
        self.assertIn('network lost',text)
        self.assertEqual(text.count('\nstopped\n'),1)

    def test_legacy_tool_events(self):
        text=self.extract([
            {'type':'event_msg','payload':{'type':'exec_command_begin','call_id':'old1',
                                         'command':['pytest']}},
            {'type':'event_msg','payload':{'type':'exec_command_end','call_id':'old1',
                                         'exit_code':1,'stderr':'FAILED'}}])
        for value in ('old1','pytest','FAILED','exit_code'):
            self.assertIn(value,text)

    def test_invalid_utf8_is_error_not_empty_success(self):
        src=self.base/'big5.jsonl'
        src.write_bytes(b'{"role":"user","content":"\xff\xfe"}')
        dst=self.base/'out.txt'
        result=self.run_script('extract_transcript.py',src,'--out',dst)
        self.assertNotEqual(result.returncode,0)
        self.assertFalse(dst.exists())

    def test_bom_accepted(self):
        src=self.base/'bom.jsonl'
        src.write_text('{"role":"user","content":"BOM works"}\n',encoding='utf-8-sig')
        result=self.run_script('extract_transcript.py',src)
        self.assertEqual(result.returncode,0,result.stderr)
        self.assertIn('BOM works',result.stdout)

    def test_scalar_json_diagnosed(self):
        src=self.log([42,{'role':'user','content':'keep this'}])
        result=self.run_script('extract_transcript.py',src)
        self.assertNotEqual(result.returncode,0)
        self.assertIn('line=1',result.stderr)
        self.assertIn('keep this',result.stdout)

    def test_hardlink_to_input_rejected(self):
        src=self.log([{'role':'user','content':'original'}])
        alias=self.base/'alias.txt'
        try:
            os.link(src,alias)
        except OSError as exc:
            self.skipTest('hardlink creation unavailable in this environment (errno={})'.format(exc.errno))
        original=src.read_bytes()
        result=self.run_script('extract_transcript.py',src,'--out',alias,'--overwrite')
        self.assertNotEqual(result.returncode,0)
        self.assertEqual(src.read_bytes(),original)

    def test_default_slim_name_retains_extension(self):
        src=self.log([{'role':'user','content':'name test'}])
        result=self.run_script('slim.py',src)
        self.assertEqual(result.returncode,0,result.stderr)
        self.assertTrue((self.base/'sample.jsonl.digest.txt').is_file())

    def test_slim_second_run_does_not_overwrite(self):
        src=self.log([{'role':'user','content':'name test'}])
        self.assertEqual(self.run_script('slim.py',src).returncode,0)
        dst=self.base/'sample.jsonl.digest.txt'
        original=dst.read_bytes()
        result=self.run_script('slim.py',src)
        self.assertNotEqual(result.returncode,0)
        self.assertEqual(dst.read_bytes(),original)

    def test_single_file_output_directory_is_created_when_marked(self):
        src=self.log([{'role':'user','content':'directory output'}])
        result=self.run_script('slim.py',src,'--out',str(self.base/'new')+os.sep)
        self.assertEqual(result.returncode,0,result.stderr)
        self.assertTrue((self.base/'new'/'sample.jsonl.digest.txt').is_file())

    def test_tool_limit_zero_keeps_full_result(self):
        body='START'+'x'*5000+'END'
        text=self.extract([{'role':'tool','content':body}], '--tool-max-chars','0')
        self.assertIn(body,text)
        self.assertNotIn('TRUNCATED',text)


if __name__ == '__main__':
    unittest.main()
