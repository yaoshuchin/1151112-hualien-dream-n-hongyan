"""Exercise output races and planning against real files."""
import os
from pathlib import Path
import sys
import tempfile
import unittest
from unittest import mock

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from common import write_text


class OutputSafetyTests(unittest.TestCase):
    @unittest.skipUnless(os.name == 'nt', 'Windows exclusive rename policy')
    def test_competing_output_created_after_preflight_is_preserved(self):
        with tempfile.TemporaryDirectory() as directory:
            target=Path(directory)/'out.txt'
            original_rename=os.rename

            def competing_rename(source,destination):
                Path(destination).write_text('COMPETING RESULT',encoding='utf-8')
                return original_rename(source,destination)

            with mock.patch('common.os.rename',side_effect=competing_rename):
                with self.assertRaises(FileExistsError):
                    write_text(target,'OUR RESULT')
            self.assertEqual(target.read_text(encoding='utf-8'),'COMPETING RESULT')
            self.assertEqual([p.name for p in Path(directory).iterdir()],['out.txt'])

    def test_failed_write_keeps_existing_output_and_removes_stage(self):
        with tempfile.TemporaryDirectory() as directory:
            target=Path(directory)/'out.txt'
            target.write_text('ORIGINAL',encoding='utf-8')
            with mock.patch('common.os.replace',side_effect=OSError('simulated disk failure')):
                with self.assertRaises(OSError):
                    write_text(target,'NEW',overwrite=True)
            self.assertEqual(target.read_text(encoding='utf-8'),'ORIGINAL')
            self.assertEqual([p.name for p in Path(directory).iterdir()],['out.txt'])
