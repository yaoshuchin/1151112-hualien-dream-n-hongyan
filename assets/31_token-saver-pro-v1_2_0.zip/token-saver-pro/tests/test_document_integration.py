"""Real conversion tests using generated documents; optional dependencies required."""
import io
import unittest
import zipfile

import test_regressions as harness


def word(path, text):
    with zipfile.ZipFile(path, 'w') as z:
        z.writestr('[Content_Types].xml',
                   '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
                   '<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>'
                   '</Types>')
        z.writestr('word/document.xml',
                   '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'
                   '<w:body><w:p><w:r><w:t>'+text+'</w:t></w:r></w:p></w:body></w:document>')


def pdf(path):
    output=io.BytesIO()
    output.write(b'%PDF-1.4\n')
    content=b'BT /F1 12 Tf 50 700 Td (PDF verified lesson) Tj ET'
    objects=[b'<< /Type /Catalog /Pages 2 0 R >>',
             b'<< /Type /Pages /Kids [3 0 R] /Count 1 >>',
             b'<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>',
             b'<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>',
             b'<< /Length '+str(len(content)).encode()+b' >>\nstream\n'+content+b'\nendstream']
    offsets=[0]
    for number,obj in enumerate(objects,1):
        offsets.append(output.tell())
        output.write(str(number).encode()+b' 0 obj\n'+obj+b'\nendobj\n')
    xref=output.tell()
    output.write(b'xref\n0 6\n0000000000 65535 f \n')
    for offset in offsets[1:]:
        output.write(('{:010d} 00000 n \n'.format(offset)).encode())
    output.write(('trailer\n<< /Size 6 /Root 1 0 R >>\nstartxref\n{}\n%%EOF'.format(xref)).encode())
    path.write_bytes(output.getvalue())


@unittest.skipUnless(harness.HAS_MARKITDOWN, 'optional MarkItDown integration unavailable')
class DocumentTests(unittest.TestCase):
    # Reuse only harness methods, without inheriting and duplicating all CLI tests.
    setUp = harness.CLITests.setUp
    run_script = harness.CLITests.run_script

    def test_docx_pptx_same_stem_keeps_independent_content(self):
        try:
            from pptx import Presentation
        except ImportError:
            self.skipTest('optional pptx dependency unavailable')
        inputs=self.base/'input'
        inputs.mkdir()
        word(inputs/'lesson.docx','WORD verified lesson')
        deck=Presentation()
        slide=deck.slides.add_slide(deck.slide_layouts[1])
        slide.shapes.title.text='PPT verified lesson'
        deck.save(inputs/'lesson.pptx')
        out=self.base/'out'
        result=self.run_script('slim.py',inputs,'--out',out)
        self.assertEqual(result.returncode,0,result.stderr+result.stdout)
        self.assertIn('WORD verified lesson',(out/'lesson.docx.md').read_text(encoding='utf-8'))
        self.assertIn('PPT verified lesson',(out/'lesson.pptx.md').read_text(encoding='utf-8'))

    def test_xlsx_cell_values_preserved(self):
        try:
            from openpyxl import Workbook
        except ImportError:
            self.skipTest('optional xlsx dependency unavailable')
        source=self.base/'lesson.xlsx'
        workbook=Workbook()
        workbook.active.append(['Topic','Hours'])
        workbook.active.append(['Energy',3])
        workbook.save(source)
        result=self.run_script('to_markdown.py',source)
        self.assertEqual(result.returncode,0,result.stderr+result.stdout)
        text=(self.base/'lesson.xlsx.md').read_text(encoding='utf-8')
        for value in ('Energy','Hours','3'):
            self.assertIn(value,text)

    def test_force_pdf_real_text_conversion(self):
        source=self.base/'lesson.pdf'
        pdf(source)
        result=self.run_script('slim.py',source,'--force-pdf')
        self.assertEqual(result.returncode,0,result.stderr+result.stdout)
        self.assertIn('PDF verified lesson',(self.base/'lesson.pdf.md').read_text(encoding='utf-8'))

    def test_standalone_batch_same_stem_no_collision(self):
        inputs=self.base/'input'
        inputs.mkdir()
        (inputs/'lesson.html').write_text('<h1>HTML independent</h1>',encoding='utf-8')
        (inputs/'lesson.csv').write_text('topic,value\nCSV independent,2',encoding='utf-8')
        out=self.base/'out'
        result=self.run_script('to_markdown.py',inputs,'--out',out)
        self.assertEqual(result.returncode,0,result.stderr+result.stdout)
        self.assertIn('HTML independent',(out/'lesson.html.md').read_text(encoding='utf-8'))
        self.assertIn('CSV independent',(out/'lesson.csv.md').read_text(encoding='utf-8'))

    def test_converter_existing_output_and_explicit_overwrite(self):
        source=self.base/'lesson.html'
        source.write_text('<p>Updated conversion</p>',encoding='utf-8')
        out=self.base/'lesson.html.md'
        out.write_text('KEEP',encoding='utf-8')
        result=self.run_script('to_markdown.py',source)
        self.assertNotEqual(result.returncode,0)
        self.assertEqual(out.read_text(encoding='utf-8'),'KEEP')
        result=self.run_script('to_markdown.py',source,'--overwrite')
        self.assertEqual(result.returncode,0,result.stderr)
        self.assertIn('Updated conversion',out.read_text(encoding='utf-8'))

    def test_empty_conversion_is_not_success(self):
        source=self.base/'empty.html'
        source.write_text('<html><body></body></html>',encoding='utf-8')
        result=self.run_script('to_markdown.py',source)
        self.assertNotEqual(result.returncode,0)
        self.assertFalse((self.base/'empty.html.md').exists())

    def test_corrupt_office_is_not_success(self):
        source=self.base/'broken.docx'
        source.write_bytes(b'not an office document')
        result=self.run_script('slim.py',source)
        self.assertNotEqual(result.returncode,0)
        self.assertFalse((self.base/'broken.docx.md').exists())
