# Changelog

## 1.2.0 — 2026-10-29

- 支援 Codex rollout response_item、自訂工具、事件、完成／中止／錯誤與 compaction summary。
- 保留雙方文字、短回覆、HTML、原始行號、時間、工具名稱／ID／輸入／結果及錯誤欄位。
- 修正頂層 role、Claude 混合工具結果及 Gemini-style parts 解析。
- 不再預設截斷使用者訊息；工具預設明示頭尾節錄，新增完整內容與 user-only 選項。
- Codex 鏡像採回合／時間與鄰近來源核對；不對所有同文發言全域去重。
- 保留空工具回傳及附件引用；省略內嵌圖片二進位。
- 輸出名稱包含原副檔名、可選遞迴保留子目錄，排除獨立輸出目錄。
- 所有 CLI 預設拒絕覆蓋，加入來源別名保護、原子寫入及覆蓋前檢查。
- 壞列／未知格式／部分失敗／空產物不再假成功；CLI 回傳非零退出碼。
- 移除隱式 pip 安裝與 break-system-packages；缺依賴明確提示，改用選用依賴清單。
- 修正文檔：bytes 不是 token、PDF 工具未內附、轉 Markdown 不保證 OCR 或資訊完整。
- 附合成資料回歸測試、實際文件轉檔整合測試及驗收紀錄。

升級注意：預設產物由 `name.md` 改為 `name.ext.md`；對話保留範圍增加，通常比舊版 digest 大。
舊 `--max-chars 1200` 仍可明確使用，但不再是預設；`--out` 與 `--force-pdf` 保留。
