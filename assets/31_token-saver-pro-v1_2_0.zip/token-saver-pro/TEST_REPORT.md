# token-saver-pro 1.2.0 測試報告

日期：2026-10-29（Asia/Taipei）。測試資料全部為合成資料，未讀取個人歷史對話。

## 驗收結果

| 環境 | 測試總數 | 通過 | 失敗／錯誤 | 略過 |
|---|---:|---:|---:|---:|
| Windows／Python 3.9.10，無可用文件轉檔後端 | 55 | 47 | 0 | 8 個選用文件整合案例 |
| Windows／Python 3.12.14／MarkItDown 0.1.9 | 55 | 54 | 0 | 1 個 hardlink 建立案例，受 sandbox 權限限制 |

兩個環境互補涵蓋全部 55 個測試；Python 3.12 略過的 hardlink 來源別名保護案例已在 Python 3.9 實跑通過。
不宣稱單一環境 55 項皆執行；完整逐項紀錄見 `test-results/python39.txt`、`python312.txt` 及同名 JSON。

## 已實際驗證的修正

- Codex response_item：user／assistant、function/custom tool 呼叫及輸出、call ID、phase、時間、原始行號。
- event-only 日誌、舊版 exec 工具事件、新舊完成事件、中止／錯誤及 compaction summary。
- 以回合／時間輔助的鏡像去重；跨回合同文、間隔一小時同文及無法證明的鏡像均保留。
- Claude 混合文字／工具／結果／錯誤／附件；頂層 role 與 Gemini-style parts。
- 短繁中回覆、HTML 範例、超過舊版 1200 字元的尾段、完整工具模式。
- 工具頭尾節錄及明確 TRUNCATED 標記；空工具回傳保留 ID。
- 使用者附件、Claude 工具附件及結構化工具輸出均不複製 inline base64。
- UTF-8 BOM、非 UTF-8、壞 JSON、非 object 列、未知結構、部分結果與非零退出碼。
- 同名 DOCX／PPTX 實際產物包含各自不同文字；HTML／CSV 同名亦分別保留。
- 遞迴資料夾保留路徑、排除輸出目錄、第二次執行預設拒絕覆蓋。
- 明確 overwrite、直接來源與 hardlink 來源保護、競態建立的既有輸出不被覆蓋、寫入失敗保留原產物並清理暫存。
- 真實生成的 Word、PPT、Excel、HTML、CSV、文字 PDF 轉檔；空 HTML 與偽裝損壞 DOCX 不假成功。
- 全部 Python 檔案以 Python 3.9 語法解析驗證。

## 回歸證據與獨立審查

實作前先以 23 個不需轉檔套件的 CLI 案例測試原 1.1：22 項失敗，重現遺漏及覆蓋問題。
完成後另從原 ZIP 解壓，套用新版 46 項 CLI 契約測試：2 通過、41 failure、2 error、1 環境略過。
後者包含新版參數／命名契約，不能解讀成原版有 43 個獨立程式缺陷；error 亦包括原版未產生預期檔名的結果。
原始 ZIP 未修改；測試只使用工作副本與暫存資料。

獨立審查曾重現跨回合誤刪、狀態遺漏、空結果／附件遺漏、內嵌二進位與 compaction 遺漏；均已加入回歸測試並修正。
使用指引另經完成狀態、重複短回覆、同名輸出、壞 JSONL 及 PDF 五個情境檢查，未發現打包阻擋問題。

## 測試範圍與限制

沒有對真實個人逐字稿或所有歷史版本格式做全面驗證；未知 schema 仍須依警告擴充。
沒有驗證圖片 OCR、音檔轉錄、EPUB、ZIP 或舊 XLS 的完整內容，也未做視覺排版／公式驗收。
POSIX 的 exclusive hardlink 分支未在 Linux／macOS 實跑；本次主要驗證 Windows 行為。
工具節錄是有損檢視，附件二進位與 thinking/reasoning 不匯出，不可取代原始日誌備份。
沒有精確 tokenizer／費用／方案額度的量測或節省比例承諾。

## 重跑

在技能資料夾執行 `python -m unittest discover -s tests -v`。
先安裝 `requirements-optional.txt` 可啟用文件整合案例；環境實際套件版本另見 `test-results/environment.txt`。
封裝後的解壓重跑結果與 ZIP SHA256 另附於交付目錄的驗收報告。
